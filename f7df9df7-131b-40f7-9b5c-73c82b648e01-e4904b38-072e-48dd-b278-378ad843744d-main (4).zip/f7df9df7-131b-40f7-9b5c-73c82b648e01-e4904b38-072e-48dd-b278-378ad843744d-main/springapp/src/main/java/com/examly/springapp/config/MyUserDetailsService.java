package com.examly.springapp.config;

public class MyUserDetailsService {
    MyUserDetailsService(){
        
    }
}