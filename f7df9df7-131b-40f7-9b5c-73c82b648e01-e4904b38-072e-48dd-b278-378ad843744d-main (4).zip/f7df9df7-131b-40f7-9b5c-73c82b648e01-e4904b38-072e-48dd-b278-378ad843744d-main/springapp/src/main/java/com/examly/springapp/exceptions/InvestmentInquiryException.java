package com.examly.springapp.exceptions;

public class InvestmentInquiryException extends RuntimeException {
    public InvestmentInquiryException(String message){
        super(message);
    }
}
